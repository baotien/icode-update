<?php
/**
 * Main file
 */
require_once dirname( __FILE__ ). '/inc/init.php';
