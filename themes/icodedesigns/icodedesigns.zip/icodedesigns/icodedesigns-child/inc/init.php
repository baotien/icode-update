<?php
/*
 * Including all function files
 *
 */
$dir = dirname( __FILE__ ).'/framework/functions/';
$files = scandir( $dir, 1 );
$file_read = array( 'php');
foreach ( $files as $file ) {
	if ( '.' !== $file && '..' !== $file ) {
		$type = explode( '.', $file ); 
    $type = array_reverse( $type );
    if( !in_array( $type[0], $file_read ) ) {
        continue;
    }
		if ( is_file( dirname( __FILE__ ).'/framework/functions/' . $file ) ) {
			require_once dirname( __FILE__ ).'/framework/functions/' . $file;
		}
	}
}
/*
 * Including all structure files
 *
 */
$dir = dirname( __FILE__ ).'/framework/structure/';
$files = scandir( $dir, 1 );
foreach ( $files as $file ) {
	$type = explode( '.', $file ); 
    $type = array_reverse( $type );
    if( !in_array( $type[0], $file_read ) ) {
        continue;
    }
	if ( '.' !== $file && '..' !== $file ) {
		if ( is_file( dirname( __FILE__ ).'/framework/structure/' . $file ) ) {
			require_once dirname( __FILE__ ).'/framework/structure/' . $file;
		}
	}
}
/*
 * Including all widgets files
 *
 */
$dir = dirname( __FILE__ ).'/framework/widgets/';
$files = scandir( $dir, 1 );
foreach ( $files as $file ) {
	$type = explode( '.', $file ); 
    $type = array_reverse( $type );
    if( !in_array( $type[0], $file_read ) ) {
        continue;
    }
	if ( '.' !== $file && '..' !== $file ) {
		if ( is_file( dirname( __FILE__ ).'/framework/widgets/' . $file ) ) {
			require_once dirname( __FILE__ ).'/framework/widgets/' . $file;
		}
	}
}