<?php
/**
 * 
 */
add_action('wp_head','icode_add_pixel');
